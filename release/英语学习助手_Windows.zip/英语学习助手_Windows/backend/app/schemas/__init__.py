# Pydantic schemas
